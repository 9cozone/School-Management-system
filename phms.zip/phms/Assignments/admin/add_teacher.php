<?php
include('php-includes/check-login.php');
include('php-includes/connect.php');
$username = $_SESSION['username'];

 ?>
 <?php
//User cliced on join
if(isset($_GET['join_user'])){
	$usernames = mysqli_real_escape_string($con,$_GET['usernames']);
	$surname = mysqli_real_escape_string($con,$_GET['surname']);
	$lastname = mysqli_real_escape_string($con,$_GET['lastname']);
	$othernames = mysqli_real_escape_string($con,$_GET['othernames']);
	$state = mysqli_real_escape_string($con,$_GET['state']);
	$lga = mysqli_real_escape_string($con,$_GET['lga']);
	$home= mysqli_real_escape_string($con,$_GET['home']);
	$address= mysqli_real_escape_string($con,$_GET['address']);
	$qualification = mysqli_real_escape_string($con,$_GET['qualification']);
	$course = mysqli_real_escape_string($con,$_GET['course']);
	$position = mysqli_real_escape_string($con,$_GET['position']);
	$class = mysqli_real_escape_string($con,$_GET['class']);
	$date = mysqli_real_escape_string($con,$_GET['date']);
	$password= mysqli_real_escape_string($con,$_GET['password']);
	$com_password= mysqli_real_escape_string($con,$_GET['com_password']);
	 
	$flag = 0;
	
	if($surname!='' && $lastname!='' && $othernames!='' && $state!='' && $lga!='' && $home!=''&& $address!=''&& $qualification!=''&& $course!=''&& $position!=''&& $password!=''&& $com_password!=''){
		//User filled all the fields.
		 
			if(username_check($usernames)){	
				if($password==$com_password)
					{ 
				 //Insert into User profile
	$query = mysqli_query($con,"insert into teachtb(`username`,`password`,`surname`,`lastname`,`othernames`,`state`,`date`,`lga`,`home`,`address`,`qualify`,`course_studied`,`position`) 
	values('$usernames','$password','$surname','$lastname','$othernames','$state','$date','$lga','$home','$address','$qualification','$course','$position')");
		
	    
		//Insert into User profile
		//$query = mysqli_query($con,"insert into news(`surname`,`lastname`,`othernames`) values('$surname','$lastname','$othernames')");
		 
		 if($query){
				 echo '<script>alert("New Staff Added Successful.");</script>';

		 } 
		
		
 
	 
				 
				 
					 
					}
					else{
				 
						echo '<script>alert("Password Does not Match.");</script>';
						}
				 
				 
				 
			}else{
				//check email
				echo '<script>alert("The username has  already been taken.");</script>';
				}
		 
		 
	}
	else{
		//check all fields are fill
		echo '<script>alert("Please fill all the fields.");</script>';
	}
	
	 
	
		 
	
}
?><!--/join user-->
<?php 
//functions
 
function username_check($usernames){
	global $con;
	
	$query = mysqli_query($con,"select * from teachtb where username='$usernames'");
	if(mysqli_num_rows($query)>0){
		return false;
	}
	else{
		return true;
	}
}

 
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>PHMS | Add New Staff</title>

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

 

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <?php include('php-includes/menu.php'); ?>

        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Add New Staff</h1>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                
                    <!-- /.col-lg-12 -->
                
                <!-- /.row -->
                <div class="row">
                	<div class="col-lg-9">
                    	<form method="GET">
                            <div class="form-group">
                                <label>SurName</label>
                                <input type="text" name="surname" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label>Lastname</label>
                                <input type="text" name="lastname" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label>OtherNames</label>
                                <input type="text" name="othernames" class="form-control" required>
                            </div>
							 
                              <div class="form-group">
                                <label>DOB</label>
                                <input type="date" name="date" class="form-control"  required>
                            </div>
                            <div class="form-group">
                                <label> State of Orgin</label>
                                <input type="text" name="state" class="form-control" required>
                            </div> 
							<div class="form-group">
                                <label>LGA </label>
                                <input type="text" name="lga" class="form-control" required>
                            </div>
							<div class="form-group">
                                <label> Home Town </label>
                                <input type="text" name="home" class="form-control" required>
                            </div>
							<div class="form-group">
                                <label> Address</label>
								<textarea cols ="90" rows = "3" name="address">
								</textarea>
                             </div>
							 <div class="form-group">
                                <label> Qualification</label>
								<select name = "qualification" >
									<option> SSCE</option>
									<option> NCE</option>
									<option> OND</option>
									<option> HND</option>
									<option> BSc</option>
									<option> Msce</option>
									<option> Phd</option>
								</select>
                             </div>
							 <div class="form-group">
                                <label> Course of Study </label>
                                <input type="text" name="course" class="form-control" required>
                            </div>
							<div class="form-group">
                                <label> Post / Duty</label>
                                <input type="text" name="position" class="form-control" required>
                            </div>	
							 <div class="form-group">
                                            <label>Class</label>
                                            <select name = "class" class="form-control">
                                                <option>Grade Five</option>
                                                <option>Grade Four</option>
                                                <option>Grade Three</option>
                                                <option>Grade Two</option>
                                                <option>Grade one</option>
                                                <option>Pre-School Three</option>
                                                <option>Pre-School Two</option>
                                                <option>Pre-School one</option>
                                                <option>Pre-School Power</option>
                                            </select>
                                        </div>
                                      
						 
							 <div class="form-group">
                                <label> UserNmame</label>
                                <input type="text" name="usernames" class="form-control" required>
                            </div>
							<div class="form-group">
                                <label> Password</label>
                                <input type="password" name="password" class="form-control" required>
                            </div>
							<div class="form-group">
                                <label> Comfirm Password</label>
                                <input type="password" name="com_password" class="form-control" required>
                            </div>
                            <div   class="form-group">
                        	<input  style = "width:100%;  " type="submit" name="join_user" class="btn btn-primary" value="Register">
                        </div>
                        </form>
                    </div>
                </div><!--/.row-->
           </div> </div>
             

    <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="dist/js/sb-admin-2.js"></script>

</body>

</html>
