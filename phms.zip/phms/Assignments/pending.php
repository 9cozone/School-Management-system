<?php
include('php-includes/check-login.php');
include('php-includes/connect.php');
$username = $_SESSION['username'];

 ?>
<?php

	
if(isset($_POST['send'])){
	$query = mysqli_query($con,"select * from pupilstb where username='$username'"); 
    $row=mysqli_fetch_array($query);

	$class=$row['class'];
	 
	$surname=$row['surname'];
	$lastname=$row['lastname'];
	$othernames=$row['othernames'];
	$reg_number=$row['reg_number'];
	
	$date_sub =  date("y-m-d");
 	$subject = mysqli_real_escape_string($con,$_POST['subject']);
	$teacher = mysqli_real_escape_string($con,$_POST['teacher']);
	$orig_file = mysqli_real_escape_string($con,$_POST['orig_file']);
   	$date_post = mysqli_real_escape_string($con,$_POST['date_post']);
 	$id = mysqli_real_escape_string($con,$_POST['id']);
 
	$myfile = $_FILES['myfile']['name'];
	// destination of the file on the server
    $destination = 'uploads/' . $myfile;
	// get the file extension
    $extension = pathinfo($myfile, PATHINFO_EXTENSION);
// the physical file on a temporary uploads directory on the server
    $file = $_FILES['myfile']['tmp_name'];
 
	   if (!in_array($extension, ['zip', 'pdf', 'docx'])) {
		   	echo '<script>alert("You file extension must be .zip, .pdf or .docx  ");window.location.assign("pending.php");</script>';	

     }else {
        // move the uploaded (temporary) file to the specified destination
        if (move_uploaded_file($file, $destination)) {
           
			$sql=mysqli_query($con,"insert into assign_sub (`username`,`class`,`surname`,`lastname`,`othernames`,`subject`,`date_sub`,`filename`,`reg_number`,`orig_file`,`teacher`)
			values('$username','$class','$surname','$lastname','$othernames','$subject','$date_sub','$myfile','$reg_number','$orig_file','$teacher')");

             if ($sql) {
				echo '<script>alert("You have successfully Submited an Assignment. Thank You");window.location.assign("pending.php");</script>';	
            }
          else {
				echo '<script>alert("Not successful.Try Again");window.location.assign("pending.php");</script>';	
        }
        }
    }

	
	
	
    
	
	
	  	
 
	
	//updae pin request status
 	 
	}
 
	
	 
	 
 
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>PHMS | Pending</title>

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

 

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <?php include('php-includes/menu.php'); ?>

        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Pending Assignments</h1>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <div class="row">
                	<div class="col-lg-12">
                    	<div class="table-responsive">
                        	<table class="table table-striped table-bordered">
                            	<tr>
									<th>S.n.</th>
                                    <th>Subject</th>
                                    <th>Teacher's Name</th>
                                    <th>Assignment</th>
                                    <th>Date</th>
                                    <th>Upload Assg.</th>
                                    <th> Submit</th>
                                 </tr>
                                <?php
									$queryy = mysqli_query($con,"select * from pupilstb where username='$username'"); 
									$row=mysqli_fetch_array($queryy);

									$class=$row['class'];
								
								
								   $querya = mysqli_query($con,"select * from assign_sub where username='$username'"); 
									$row=mysqli_fetch_array($querya);

									$orig_file_sub=$row['orig_file'];
									$subject_sub=$row['subject'];
								
									$query = mysqli_query($con,"select * from assignments where class='$class' ");
									if(mysqli_num_rows($query)>0){
										$i=1;
										while($row=mysqli_fetch_array($query)){
											$id = $row['id'];
											$subject = $row['subject'];
											$teacher = $row['teacher'];
											$orig_file = $row['filename'];
  											$date_post = $row['date_posted'];
											$destination = 'uploads/' . $orig_file;
 									
										?>
                                        	<tr>
                                            	<td><?php echo $i; ?></td>
												<td><?php echo $subject; ?></td>
												<td><?php echo $teacher; ?></td>
												<td><a href="<?php echo $destination ;?>"><?php echo $orig_file; ?></a> </td>
 												<td><?php 	echo $date_post; ?></td>
							
                                                <form method="post" enctype="multipart/form-data" >
                                                <input type="hidden" name="id" value="<?php echo $id ?>">
												<input type="hidden" name="subject" value="<?php echo $subject ?>">
												<input type="hidden" name="teacher" value="<?php echo $teacher ?>">
												<input type="hidden" name="orig_file" value="<?php echo $orig_file ?>">
												<input type="hidden" name="date_post" value="<?php echo $date_post ?>">
												<?php 
													if($orig_file_sub ==$orig_file ){
													?>
													<td style ="background-color:green; color:white; text-align:center; font-size:17px;"> Already Submited</td>
                                                	<td><img src ="../img/tick.png"> <td> <img src ="../img/lock.png"></td></td>
													<?php
													}else{
														?>
													<td><input type="file" name="myfile"   class="btn btn-primary"></td>
                                                	<td><input type="submit" name="send" value="Send" class="btn btn-primary"></td>
													<?php
													}
													?>
											   </form>
                                             </tr>
                                        <?php
											$i++;
										}
									}
									else{
									?>
                                    	<tr>
                                        	<td colspan="12" align="center">You have no Assignment.</td>
                                        </tr>
                                    <?php
									}
								?>
                            </table>
							
                        </div><!--/.table-responsive-->
                    </div>
                </div><!--/.row-->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="dist/js/sb-admin-2.js"></script>

</body>

</html>
