-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 05, 2020 at 12:36 PM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `phms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(33) NOT NULL,
  `password` varchar(33) NOT NULL,
  `surname` varchar(444) NOT NULL,
  `lastname` varchar(44) NOT NULL,
  `othername` varchar(44) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `surname`, `lastname`, `othername`) VALUES
(1, 'admin', 'admin', 'Admin', 'Nichollas', 'Anyim');

-- --------------------------------------------------------

--
-- Table structure for table `assignments`
--

DROP TABLE IF EXISTS `assignments`;
CREATE TABLE IF NOT EXISTS `assignments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(33) NOT NULL,
  `subject` varchar(33) NOT NULL,
  `teacher` varchar(33) NOT NULL,
  `filename` varchar(33) NOT NULL,
  `date_posted` varchar(33) NOT NULL,
  `class` varchar(33) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assignments`
--

INSERT INTO `assignments` (`id`, `username`, `subject`, `teacher`, `filename`, `date_posted`, `class`) VALUES
(1, 'aa', 'English Language', 'Admin', 'compensation_explanation.docx', '20-01-18', 'Grade Five'),
(2, 'Nikol', 'Mathematics', 'Anyim', 'reporthh.docx', '20-01-18', 'Grade Five');

-- --------------------------------------------------------

--
-- Table structure for table `assign_sub`
--

DROP TABLE IF EXISTS `assign_sub`;
CREATE TABLE IF NOT EXISTS `assign_sub` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(55) NOT NULL,
  `class` varchar(55) NOT NULL,
  `surname` varchar(55) NOT NULL,
  `lastname` varchar(55) NOT NULL,
  `othernames` varchar(55) NOT NULL,
  `subject` varchar(55) NOT NULL,
  `date_sub` varchar(55) NOT NULL,
  `filename` varchar(55) NOT NULL,
  `reg_number` varchar(33) NOT NULL,
  `orig_file` varchar(33) NOT NULL,
  `teacher` varchar(33) NOT NULL,
  `status` enum('UNMARKED','MARKED') NOT NULL DEFAULT 'UNMARKED',
  `score` int(11) DEFAULT NULL,
  `remark` longtext,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assign_sub`
--

INSERT INTO `assign_sub` (`id`, `username`, `class`, `surname`, `lastname`, `othernames`, `subject`, `date_sub`, `filename`, `reg_number`, `orig_file`, `teacher`, `status`, `score`, `remark`) VALUES
(1, 'samuel', 'Grade Five', 'Akinbola', 'Samuel', 'John', 'English Language', '20-01-18', 'django.pdf', 'CS/H2019/R/003', 'compensation_explanation.docx', 'Admin', 'UNMARKED', NULL, NULL),
(2, 'samuel', 'Grade Five', 'Akinbola', 'Samuel', 'John', 'Mathematics', '20-01-19', 'I.C.T.pdf', 'CS/H2019/R/003', 'reporthh.docx', 'Anyim', 'UNMARKED', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `header`
--

DROP TABLE IF EXISTS `header`;
CREATE TABLE IF NOT EXISTS `header` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `logo` varchar(222) NOT NULL,
  `find_us` longtext NOT NULL,
  `school_time` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ps_classes`
--

DROP TABLE IF EXISTS `ps_classes`;
CREATE TABLE IF NOT EXISTS `ps_classes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(55) NOT NULL,
  `videos` longtext NOT NULL,
  `subject` varchar(55) NOT NULL,
  `date` varchar(55) NOT NULL,
  `questions` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pupilstb`
--

DROP TABLE IF EXISTS `pupilstb`;
CREATE TABLE IF NOT EXISTS `pupilstb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(44) NOT NULL,
  `password` varchar(44) NOT NULL,
  `surname` varchar(44) NOT NULL,
  `lastname` varchar(44) NOT NULL,
  `othernames` varchar(44) NOT NULL,
  `class` varchar(44) NOT NULL,
  `dob` varchar(44) NOT NULL,
  `state` varchar(44) NOT NULL,
  `reg_number` varchar(44) NOT NULL,
  `address` varchar(44) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pupilstb`
--

INSERT INTO `pupilstb` (`id`, `username`, `password`, `surname`, `lastname`, `othernames`, `class`, `dob`, `state`, `reg_number`, `address`) VALUES
(1, 'samuel', '123456', 'Akinbola', 'Samuel', 'John', 'Grade Five', '10-02-2020', 'Osun', 'CS/H2019/R/003', 'No 23 Anamco, Enugu 								');

-- --------------------------------------------------------

--
-- Table structure for table `teachtb`
--

DROP TABLE IF EXISTS `teachtb`;
CREATE TABLE IF NOT EXISTS `teachtb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(55) NOT NULL,
  `password` varchar(55) NOT NULL,
  `surname` varchar(55) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `othernames` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  `lga` varchar(50) NOT NULL,
  `home` varchar(50) NOT NULL,
  `address` varchar(55) NOT NULL,
  `qualify` varchar(55) NOT NULL,
  `course_studied` varchar(55) NOT NULL,
  `position` varchar(55) NOT NULL,
  `class` varchar(33) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teachtb`
--

INSERT INTO `teachtb` (`id`, `username`, `password`, `surname`, `lastname`, `othernames`, `state`, `date`, `lga`, `home`, `address`, `qualify`, `course_studied`, `position`, `class`) VALUES
(1, 'Nikol', '123456', 'Anyim', 'Nicholas', 'Emeka', 'Enugu', '10-04-1995', 'Aninri', 'Oduma', 'No 23 Edinburgh Road , Enugu								', 'HND', 'computer science', 'Staff', NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
