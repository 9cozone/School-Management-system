<?php
include('php-includes/check-login.php');
include('php-includes/connect.php');
$username = $_SESSION['username'];

 ?>
<?php

	
if(isset($_POST['send'])){
	 
 	$score = mysqli_real_escape_string($con,$_POST['score']);
 	$remark = mysqli_real_escape_string($con,$_POST['remark']);
 
  
	$query = mysqli_query( $con, " UPDATE assign_sub SET status ='MARKED' && score ='$score' && remark='$remark' where id = '$id' limit 1");
	//mysqli_query($con,"insert into assign_sub (`username`,`class`,`surname`,`lastname`,`othernames`,`subject`,`date_sub`,`filename`,`reg_number`,`orig_file`,`teacher`)
	//values('$username','$class','$surname','$lastname','$othernames','$subject','$date_sub','$filename','$reg_number','$orig_file','$teacher')");

	  	
 
	
	//updae pin request status
 	 
	echo '<script>alert("You have successfully Submited an Assignment. Thank You");window.location.assign("pending.php");</script>';	
	}
 
	
	 
	 
 
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>PHMS | Pending</title>

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

 

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <?php include('php-includes/menu.php'); ?>

        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Submited Assignments</h1>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <div class="row">
                	<div class="col-lg-12">
                    	<div class="table-responsive">
                        	<table class="table table-striped table-bordered">
                            	<tr>
									<th>S.n.</th>
                                    <th>surname</th>
                                    <th>lastname</th>
                                    <th>othernames</th>
                                    <th>Subject</th>
                                    <th>Teacher's Name</th>
                                    <th>Assignment</th>
                                    <th>Date Submited</th>
                                    <th>Submited Assign.</th>
                                    <th>Status</th>
                                    <th>Score</th>
                                    <th>Remark</th>
                                    <th>Action</th>
                                 </tr>
                                <?php
									 $query = mysqli_query($con,"select * from teachtb where username='$username'"); 
									$row=mysqli_fetch_array($query);

									$class=$row['class'];
									 
									  
								   $querya = mysqli_query($con,"select * from assign_sub where status='UNMARKED' && class ='$class'"); 
									 							
 									if(mysqli_num_rows($querya)>0){
										$i=1;
										while($row=mysqli_fetch_array($querya)){
											$id = $row['id'];
											$surname = $row['surname'];
											$lastname = $row['lastname'];
											$othernames = $row['othernames'];
 											$subject = $row['subject'];
											$teacher = $row['teacher'];
											$filename = $row['orig_file'];
											
  											$date_post = $row['date_sub'];
											$sub_file = $row['filename'];
											$status = $row['status'];
											$loc_filename = '../uploads/' . $filename;
											$loc_sub_file = '../uploads/' . $sub_file;
										?>
                                        	<tr>
                                            	<td><?php echo $i; ?></td>
												<td><?php echo $surname; ?></td>
												<td><?php echo $lastname; ?></td>
												<td><?php echo $othernames; ?></td>
												<td><?php echo $subject; ?></td>
												<td><?php echo $teacher; ?></td>
												
												<td><a href="<?php echo $loc_filename ;?>">
												<?php echo $filename; ?></a>
												
												</td>
												
												<td><?php echo $date_post; ?></td>
 												
												<td><a href="<?php echo $loc_sub_file ;?>">
												<?php echo $sub_file; ?></a>
												
												</td>
												
 												<td style = "color:white; text-align:center;background-color:red;"><?php echo $status; ?></td>
												<td>
												<form method ="POST">
													 
													<select name ="score" >
														<option> 1</option>
														<option> 2</option>
														<option> 3</option>
														<option> 4</option>
														<option> 5</option>
														<option> 6</option>
														<option> 7</option>
														<option> 8</option>
														<option> 9</option>
														<option> 10</option>
														<option> 11</option>
														<option> 12</option>
														<option> 13</option>
														<option> 14</option>
														<option> 15</option>
														<option> 16</option>
														<option> 17</option>
														<option> 18</option>
														<option> 19</option>
														<option> 20</option>
														</select>
												 
												</td>
										<input type ="hidden" name="id" value= "<?php echo $teacher; ?>">
												<td>
													<select name ="remark" >
														<option> Failed</option>
														<option> V.Poor</option>
														<option> Poor</option>
														<option> Good</option>
														<option> V.Good</option>
														<option> Excellent</option>
														</select>
												</td>
												<td>
												<input type = "submit" name ="send" value = "Post">
												<td>
												</form>
                                              </tr>
											  
                                        <?php
											$i++;
										}
									}
									else{
									?>
                                    	<tr>
                                        	<td colspan="12" align="center">You have no Assignment Posted yes</td>
                                        </tr>
                                    <?php
									}
								?>
                            </table>
							
                        </div><!--/.table-responsive-->
                    </div>
                </div><!--/.row-->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="dist/js/sb-admin-2.js"></script>

</body>

</html>
