<?php
include('php-includes/check-login.php');
include('php-includes/connect.php');

$username = $_SESSION['username'];
 ?>
<?php

	
if(isset($_POST['send'])){
	$query = mysqli_query($con,"select * from teachtb where username='$username'"); 
    $row=mysqli_fetch_array($query);
	$teacher=$row['surname'];
	$date_post =  date("y-m-d");
 	$class = mysqli_real_escape_string($con,$_POST['class']);
 	$subject = mysqli_real_escape_string($con,$_POST['subject']);
	$myfile = $_FILES['myfile']['name'];
	// destination of the file on the server
    $destination = '../uploads/' . $myfile;
	// get the file extension
    $extension = pathinfo($myfile, PATHINFO_EXTENSION);
// the physical file on a temporary uploads directory on the server
    $file = $_FILES['myfile']['tmp_name'];
	
	   if (!in_array($extension, ['zip', 'pdf', 'docx'])) {
		   	echo '<script>alert("You file extension must be .zip, .pdf or .docx  ");window.location.assign("post_assignment.php");</script>';	

     }else {
        // move the uploaded (temporary) file to the specified destination
        if (move_uploaded_file($file, $destination)) {
           
			$sql=mysqli_query($con,"insert into assignments (`username`,`subject`,`teacher`,`filename`,`date_posted`,`class`)
			values('$username','$subject','$teacher','$myfile','$date_post','$class')");

             if ($sql) {
				echo '<script>alert("You have successfully Submited an Assignment. Thank You");window.location.assign("post_assignment.php");</script>';	
            }
          else {
				echo '<script>alert("Not successful.Try Again");window.location.assign("post_assignment.php");</script>';	
        }
        }
    }

	
	
	
    
	
	
	  	
 
	
	//updae pin request status
 	 
	}
 
	
	 
	 
 
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>PHMS | Pending</title>

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

 

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <?php include('php-includes/menu.php'); ?>

        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Post  Assignments</h1>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <div class="row">
                	<div class="col-lg-12">
                       	<form method="POST" enctype="multipart/form-data">
                              <div class="form-group">
                                            <label>Subject</label>
                                            <select name = "subject" class="form-control">
										

                                                <option> English Language</option>
											
                                                <option>Mathematics </option>
                                                <option>Christian Religious Knowledge</option>
                                                <option>Social Studies </option>
                                                <option>Citiizenship Educaiton</option>
                                                <option>Health Education</option>
                                                <option>Home Economices </option>
                                                <option>Agricultural Science</option>
                                                <option>Moral instruction<option>
                                                <option> French language<option>
                                                <option>Igbo language<option>
                                                <option>Computer Education<option>
                                                <option>Quantitative Reason <option>
                                                <option>Verbal Aptitudes <option>
                                                <option>Creative Arts /Fine Arts   <option>
                                                <option>Vocational Aptitude   <option>
                                                <option> Music    <option>
                                                <option>Basic Science<option>
                                            </select>
                                        </div>
							
                         <div class="form-group">
                                            <label>Class</label>
                                            <select name = "class" class="form-control">
                                                <option>Grade Five</option>
                                                <option>Grade Four</option>
                                                <option>Grade Three</option>
                                                <option>Grade Two</option>
                                                <option>Grade one</option>
                                                <option>Pre-School Three</option>
                                                <option>Pre-School Two</option>
                                                <option>Pre-School one</option>
                                                <option>Pre-School Power</option>
                                            </select>
                                        </div>
                                      <div class="form-group">
                                <label>Assignment</label>
                                <input type="file" name="myfile" class="form-control" required>
                            </div>
                             
                             
                            <div   class="form-group">
                        	<input  style = "width:100%;" type="submit" name="send" class="btn btn-primary" value="Register">
                        </div>
                        </form>
                  </div>
                </div><!--/.row-->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="dist/js/sb-admin-2.js"></script>

</body>

</html>
