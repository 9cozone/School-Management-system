<!DOCTYPE html>
<html lang="en">
<head>
	<title>Admission form | PHMS</title>
	<meta charset="UTF-8">
	<meta name="description" content="Potter's House  Montesorri">
	<meta name="keywords" content="event, Enugu, creative, school, Ngwo">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Favicon -->   
	<link href="img/favicon.ico" rel="shortcut icon"/>

	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Rubik:400,400i,500,500i,700,700i" rel="stylesheet">

	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/themify-icons.css"/>
	<link rel="stylesheet" href="css/owl.carousel.css"/>
	<link rel="stylesheet" href="css/style.css"/>


	<!--[if lt IE 9]>
	  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

</head>
<body>
	<!-- Page Preloder -->
	<div id="preloder">
		<div class="loader"></div>
	</div>


	<!-- header section -->
	<header class="header-section">
		<div class="container">
			<!-- logo -->
			<a href="index.html" class="site-logo"><img src="img/logo.png" alt=""></a>
			<div class="nav-switch">
				<i class="fa fa-bars"></i>
			</div>
			<div class="header-info">
				<div class="hf-item">
					<i class="fa fa-clock-o"></i>
					<p><span>School time:</span>Monday - Friday: 07 AM - 06 PM</p>
				</div>
				<div class="hf-item">
					<i class="fa fa-map-marker"></i>
					<p><span>Find us:</span>  Bora Farm Road, Hill-Top  Ngwo Enugu Nigeria.</p>
				</div>
			</div>
		</div>
	</header>
	<!-- header section end-->


	<!-- Header section  -->
	<nav class="nav-section">
		<div class="container">
			<div class="nav-right">
				<a href=""><i class="fa fa-search"></i></a>
				<a href=""><i class="fa fa-shopping-cart"></i></a>
			</div>
			<ul class="main-menu">
				<li class="active"><a href="index.html">Home</a></li>
				<li><a href="about.html">About Us</a></li>
				<li><a href="programmes.html">Our Programmes</a></li>
				<li><a href="admission.html">Admission</a></li>
				<li><a href="Assignments/index.php">Assignments</a></li>
				<li><a href="contact.html">Contact</a></li>
			</ul>
		</div>
	</nav>
	<!-- Header section end -->



	<!-- Breadcrumb section -->
	<div class="site-breadcrumb">
		<div class="container">
			<a href="#"><i class="fa fa-home"></i> Home</a> <i class="fa fa-angle-right"></i>
			<span>Admission Form </span>
		</div>
	</div>
	<!-- Breadcrumb section end -->


	<!-- Courses section -->
	<section class="contact-page spad pt-0">
		<div class="container">
		 	<div class="contact-form spad pb-0">
				<div class="section-title text-center">
					<h3>Admission Form</h3>
					 
				</div>
				<form class="comment-form --contact">
					<div class="row">
						<div class="col-lg-4">
						<h4> Child's Information</h4>
							<input type="text" name ="surname" placeholder="Your Surname">
						</div>
						<div class="col-lg-4">
							<input type="text" name ="firstname" placeholder="Your First Name">
						</div>
					 
						<div class="col-lg-4">
							<input type="text" name ="middle_name" placeholder="Your Middle Name">
						</div><br>
						<div class="col-lg-4">
							Gender: <select name = "gender"><option> Male</option><option>Female</option></select>
						<br><br>
						</div>
						<div class="col-lg-4">
						<lable>Date of Birth</lable>
						<input type="date" name ="dob" ">
						<br><br>
						</div>
						<div class="col-lg-4">
							<input type="text" name ="religion" placeholder="Your Religion">
						</div>	
						<div class="col-lg-4">
							<input type="text" name ="nationality" placeholder="Your Nationality">
						</div>
						<div class="col-lg-4">
							<input type="text" name ="lga" placeholder="Local Government of Orgin">
						</div>	
						<div class="col-lg-4">
							<input type="text" name ="town" placeholder="Town ">
						</div>	<br>
						<div class="col-lg-4">
							Programmes: <select name = "programme">
							<option> Crèche/Day Care</option>
							<option>Pre-school /Nursery</option>
							<option>Pre-school /Nursery</option>
							<option>Basic school / Primary </option>
							<option>Extra–mural Classes </option>
							<option> Secondary School </option>
							</select>
								<br>	<br>
						</div>					 
						 <div class="col-lg-4">
							Grade: <select name = "grade">
							 <option>Grade Five</option>
                                                <option>Grade Four</option>
                                                <option>Grade Three</option>
                                                <option>Grade Two</option>
                                                <option>Grade one</option>
                                                <option>Pre-School Three</option>
                                                <option>Pre-School Two</option>
                                                <option>Pre-School one</option>
                                                <option>Pre-School Power</option>
                                         
							</select>
								<br>	<br>
						</div>	 					 
						 <div class="col-lg-4">
							<input type="text" name ="prev_school" placeholder="Previous school Attended(If any)">
						</div>
						<div class="col-lg-4">
						<h4> Parents/Guardians Information</h4>
							<input type="text" name ="fa_surname" placeholder="Father's Surname">
						</div>
						<div class="col-lg-4">
							<input type="text" name ="fa_firstname" placeholder="Father's   First Name">
						</div>
						 
						<div class="col-lg-4">
							<input type="text" name ="fa_middle_name" placeholder=" Father's  Middle Name">
						</div>
						<div class="col-lg-4">
						 
							<input type="text" name ="mo_surname" placeholder="Mother's Surname">
						</div>
						<div class="col-lg-4">
							<input type="text" name ="mo_firstname" placeholder="Mother's   First Name">
						</div>
						 
						<div class="col-lg-4">
							<input type="text" name ="mo_middle_name" placeholder=" Mother's  Middle Name">
						</div>
						
						<div class="col-lg-4">
						<h4> Parents/Guardians Occupations</h4>
							<input type="text" name ="fa_oc" placeholder="Father's Occupation">
						</div>
						<div class="col-lg-4">
						 
							<input type="text" name ="fa_phone_number" placeholder="Father's Phone Number">
						</div>
						<div class="col-lg-4">
						 
							<input type="text" name ="mo_oc" placeholder="Mother's Occupation">
						</div>
						<div class="col-lg-4">
						 
							<input type="text" name ="mo_phone_number" placeholder="Mother's Phone Number">
						</div>
						<div class="col-lg-4">
						 
							<p>Does the child have any Disability?</p>
							<lable>Yes</lable><input type="radio" name ="disable" value="YES">
							<lable>No</lable><input type="radio" name ="disable" value="No">
							<br>	<br>
						</div>
						<div class="col-lg-4">
							
							<input type="text" name ="profession" placeholder=" What do you wish your child takes up as a Profession?">
						</div>
						<br>
						<div class="col-lg-12">
							<textarea name = "interest" placeholder="Child's Interests"></textarea>
							<div class="text-center">
								<button class="site-btn">SUBMIT</button>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</section>
	<!-- Courses section end-->


	<!-- Newsletter section -->
	<section class="newsletter-section">
		<div class="container">
			<div class="row">
				<div class="col-md-5 col-lg-7">
					<div class="section-title mb-md-0">
					<h3>NEWSLETTER</h3>
					<p>Subscribe and get the latest news and useful tips, advice and best offer.</p>
				</div>
				</div>
				<div class="col-md-7 col-lg-5">
					<form class="newsletter">
						<input type="text" placeholder="Enter your email">
						<button class="site-btn">SUBSCRIBE</button>
					</form>
				</div>
			</div>
		</div>
	</section>
	<!-- Newsletter section end -->	

	<!-- Footer section -->
	<!-- Footer section -->
	<footer class="footer-section">
		<div class="container footer-top">
			<div class="row">
				<!-- widget -->
				<div class="col-sm-6 col-lg-3 footer-widget">
					<div class="about-widget">
						<h6 class="fw-title">PHMS </h6>
						<p>We out for national transformation,
						through right inculcation of knowledge,
							practical skills and moral values at 
							the bases of the fear of God.
					</p>
						<div class="social pt-1">
							<a href=""><i class="fa fa-twitter-square"></i></a>
							<a href=""><i class="fa fa-facebook-square"></i></a>
							<a href=""><i class="fa fa-google-plus-square"></i></a>
							<a href=""><i class="fa fa-linkedin-square"></i></a>
							<a href=""><i class="fa fa-rss-square"></i></a>
						</div>
					</div>
				</div>
				<!-- widget -->
				<div class="col-sm-6 col-lg-3 footer-widget">
					<h6 class="fw-title">USEFUL LINK</h6>
					<div class="dobule-link">
						<ul>
							<li><a href="">Home</a></li>
							<li><a href="">About us</a></li>
							<li><a href="">Events</a></li>
							<li><a href="">Admission</a></li>
							<li><a href="">Contact</a></li>
						</ul>
						<ul>
							<li><a href="">Policy</a></li>
							<li><a href="">Term</a></li>
							<li><a href="">Help</a></li>
							<li><a href="">FAQs</a></li>
							<li><a href="">Site map</a></li>
						</ul>
					</div>
				</div>
				<!-- widget -->
				 <!-- widget -->
				<div class="col-sm-6 col-lg-3 footer-widget">
					<h6 class="fw-title">OUR SCHOOLS</h6>
					<ul class="contact">
						<li>
						<a href="">CRECHE</a></li>
							<li><a href="">NURSERY</a></li>
							<li><a href="">PRIMARY</a></li>
							<li><a href="">SECONDARY (In Progress) </a></li>
							 </ul>
				</div>
				<div class="col-sm-6 col-lg-3 footer-widget">
					<h6 class="fw-title">CONTACT</h6>
					<ul class="contact">
						<li><p><i class="fa fa-map-marker"></i> Bora Farm Road, Hill-Top Ngwo Enugu Nigeria</p></li>
						<li><p><i class="fa fa-phone"></i> (+234) 08060453412 </p></li>
						<li><p><i class="fa fa-envelope"></i>phms@gmail.com</p></li>
						<li><p><i class="fa fa-clock-o"></i> Monday - Friday, 07:00AM - 06:00 PM</p></li>
					</ul>
				</div>
			</div>
		</div>
		<!-- copyright -->
		<div class="copyright">
			<div class="container">
				<p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
			Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | PHMS <i class="fa fa-heart-o" aria-hidden="true"></i>   
 			</div>		
		</div>
	</footer>
	<!-- Footer section end-->



	<!--====== Javascripts & Jquery ======-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.countdown.js"></script>
	<script src="js/masonry.pkgd.min.js"></script>
	<script src="js/magnific-popup.min.js"></script>
	<script src="js/main.js"></script>


	<!-- load for map -->
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB0YyDTa0qqOjIerob2VTIwo_XVMhrruxo"></script>
	<script src="js/map.js"></script>
	
</body>
</html>